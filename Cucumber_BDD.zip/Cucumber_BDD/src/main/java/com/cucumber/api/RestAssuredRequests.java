package com.cucumber.api;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestAssuredRequests {
	
	public static Response response=null;

	public static void setBaseURI(String baseURI) {
		RestAssured.baseURI = baseURI;
	}
	
	public static void setPathParameter(String pathParameter) {
		RestAssured.basePath = pathParameter;
	}
	
	public static void getRequest() {		
        response = RestAssured.given()
                .contentType(ContentType.JSON)
                .when()
                .get()
                .then()
                .extract().response();
        }
	
		/*
		 * public static Response getRequest(String baseURI,String pathParameter) {
		 * RestAssured.baseURI = baseURI; RestAssured.basePath=pathParameter;
		 * 
		 * Response response = RestAssured.given() .contentType(ContentType.JSON)
		 * .when() .get() .then() .extract().response(); return response; }
		 */
	
	public static void getRequest(String queryParameter,String queryParameterValue) {
//		RestAssured.baseURI = baseURI;
//		RestAssured.basePath=pathParameter;
		
         response = RestAssured.given()
                .contentType(ContentType.JSON)
                .param(queryParameter, queryParameterValue)
                .when()
                .get()
                .then()
                .extract().response();	
	}
	
	/*
	 * public static Response postRequest(String baseURI,String pathParameter,String
	 * requestBody) { RestAssured.baseURI = baseURI;
	 * RestAssured.basePath=pathParameter; Response response = RestAssured.given()
	 * .header("Content-type", "application/json") .and() .body(requestBody) .when()
	 * .post() .then() .extract().response(); return response; }
	 */
	 
	 public static void postRequest_JsonFileAsBody(String filePath) {
//		 RestAssured.baseURI = baseURI;
//		 RestAssured.basePath=pathParameter;	 
		 
		 File jsonFile = new File(filePath);
	     response = RestAssured.given()
                .header("Content-type", "application/json")
                .and()
                .body(jsonFile)
                .when()
                .post()
                .then()
                .extract().response();		
	 }
	 
		/*
		 * public static Response putRequest(String baseURI,String pathParameter,String
		 * requestBody) { RestAssured.baseURI = baseURI;
		 * RestAssured.basePath=pathParameter; Response response = RestAssured.given()
		 * .header("Content-type", "application/json") .and() .body(requestBody) .when()
		 * .put() .then() .extract().response(); return response; }
		 */
	 
	 public static void putRequest_JsonFileAsBody(String filePath) {
//		 RestAssured.baseURI = baseURI;
//		 RestAssured.basePath=pathParameter;	 
		 
		 File jsonFile = new File(filePath);
	     response = RestAssured.given()
                .header("Content-type", "application/json")
                .and()
                .body(jsonFile)
                .when()
                .put()
                .then()
                .extract().response();		
	 }
	 
		/*
		 * public static Response patchRequest(String baseURI,String
		 * pathParameter,String requestBody) { RestAssured.baseURI = baseURI;
		 * RestAssured.basePath=pathParameter; Response response = RestAssured.given()
		 * .header("Content-type", "application/json") .and() .body(requestBody) .when()
		 * .patch() .then() .extract().response(); return response; }
		 */
	 
	 public static void patchRequest_JsonFileAsBody(String filePath) {
//		 RestAssured.baseURI = baseURI;
//		 RestAssured.basePath=pathParameter;	 
		 
		 File jsonFile = new File(filePath);
	      response = RestAssured.given()
                .header("Content-type", "application/json")
                .and()
                .body(jsonFile)
                .when()
                .patch()
                .then()
                .extract().response();		
	 }
	 
		
		public static void deleteRequest() {
//			RestAssured.baseURI = baseURI;
//			RestAssured.basePath=pathParameter;
			
	        response = RestAssured.given()
	                .contentType(ContentType.JSON)
	                .when()
	                .delete()
	                .then()
	                .extract().response();			
	    }
}
