package com.cucumber.drivers;

import java.net.MalformedURLException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;

public class InitializeDriver {

	public static WebDriver driver = null;
	public Capabilities capabilities;

	public static WebDriver setDriver(String runMode,String browser) throws MalformedURLException {

		try {
			System.out.println("Test is running on " + browser + " in " + runMode + " mode");

			switch (runMode) {
			case "Web":
				if (browser.equalsIgnoreCase("Chrome")) {
					WebDriverManager.chromedriver().setup();	
					driver= new ChromeDriver();					
				} else if (browser.equalsIgnoreCase("FireFox")) {
					WebDriverManager.firefoxdriver().setup();	
					driver= new FirefoxDriver();
				} else if (browser.equalsIgnoreCase("Edge")) {
					WebDriverManager.edgedriver().setup();				
					driver= new EdgeDriver();
				}				
				driver.manage().window().maximize();
				
				driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				break;
			case "API":
				break;			
			default:
				System.out.println("Please specify correct run mode....");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return driver;
	}

	public static void waitUntilElementVisible(WebDriver driver, String xpath) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	}

}
