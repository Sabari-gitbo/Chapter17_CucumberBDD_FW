package com.cucumber.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CommonUtils {

	public static String getCellValue(String scenarioName, String columnName) throws Exception {
		String line;
		String cellValue = "";
		boolean blnFound = false;
		BufferedReader br = null;
		int j = 0, colno = 0;

		try {
			br = new BufferedReader(new FileReader(System.getProperty("user.dir") + "//src//test//resources//TestData.csv"));
			while ((line = br.readLine()) != null) {
				String[] testData = line.split(",");

				try {
					if (blnFound == false) {
						int colCount = testData.length;
						for (j = 0; j < colCount; j++) {
							if (testData[j].equalsIgnoreCase(columnName)) {
								colno = j;
								blnFound = true;
								break;
							}
						}
					}
					if (testData[0].equals(scenarioName)) {
						cellValue = testData[colno];
						break;
					}
				} catch (Exception e) {
					cellValue = "";
				}
			}
		} catch (FileNotFoundException e) {			
			e.printStackTrace();
		} 
		br.close();
		return cellValue;		
	}
	
	 public static String getCellValue(String filePath, String testCaseId, String columnName) throws IOException {
	        FileInputStream fis = new FileInputStream(filePath);
	        XSSFWorkbook workbook = new XSSFWorkbook(fis);
	        Sheet sheet = workbook.getSheetAt(0);

	        int testCaseIdColumnIndex = -1;
	        int targetColumnIndex = -1;

	        // Get header row (assumed to be the first row)
	        Row headerRow = sheet.getRow(0);
	        if (headerRow != null) {
	            for (Cell cell : headerRow) {
	                String headerName = cell.getStringCellValue();
	                if (headerName.equalsIgnoreCase("ScenarioName")) {
	                    testCaseIdColumnIndex = cell.getColumnIndex();
	                } else if (headerName.equals(columnName)) {
	                    targetColumnIndex = cell.getColumnIndex();
	                }
	            }
	        }

	        if (testCaseIdColumnIndex == -1 || targetColumnIndex == -1) {
	            workbook.close();
	            throw new IllegalArgumentException("Invalid TestCaseID column or target column name.");
	        }

	        // Iterate over rows to find the matching Test Case ID
	        Iterator<Row> rowIterator = sheet.iterator();
	        while (rowIterator.hasNext()) {
	            Row row = rowIterator.next();
	            Cell testCaseIdCell = row.getCell(testCaseIdColumnIndex);

	            if (testCaseIdCell != null && testCaseIdCell.getStringCellValue().equals(testCaseId)) {
	                Cell targetCell = row.getCell(targetColumnIndex);
	                workbook.close();
	                return targetCell != null ? targetCell.toString() : null;
	            }
	        }

	        workbook.close();
	        return null; // return null if no match found
	    }
}
