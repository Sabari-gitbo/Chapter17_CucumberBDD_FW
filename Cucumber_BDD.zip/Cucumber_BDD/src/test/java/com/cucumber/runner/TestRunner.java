package com.cucumber.runner;

import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import com.cucumber.drivers.InitializeDriver;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src//test//java//com//cucumber//resources//Feature Files", glue = {
		"com.cucumber.stepdefinitions" }, plugin = { "pretty",
				"html:output/html-report.html" }, tags = "@DELETE", monochrome = true)

public class TestRunner extends AbstractTestNGCucumberTests {
	public static WebDriver driver;

	@BeforeTest
	@Parameters({ "Mode", "BrowserType" })
	public void setUp(String mode, String browserType) throws MalformedURLException {
		System.out.println("Run Mode is:" + mode + " : Run Browser Type is:" + browserType);
		if (!mode.equals("API")) {
			driver = InitializeDriver.setDriver(mode, browserType);
		}
	}

	@AfterTest
	public void generateExtendReport() {
		if (driver != null) {
			driver.close();
			driver.quit();
		}
	}

}
