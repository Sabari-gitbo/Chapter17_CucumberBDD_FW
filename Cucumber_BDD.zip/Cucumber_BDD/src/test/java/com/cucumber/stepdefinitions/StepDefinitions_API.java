package com.cucumber.stepdefinitions;

import org.testng.Assert;

import com.cucumber.api.RestAssuredRequests;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions_API extends RestAssuredRequests {

	@Given("the base URI is set to {string}")
	public void the_base_uri_is_set_to(String baseURI) {
		setBaseURI(baseURI);
	}

	@Given("the path parameter is set to {string}")
	public void the_path_parameter_is_set_to(String pathParameter) {
		setPathParameter(pathParameter);
	}

	@When("I send a GET request")
	public void i_send_a_get_request() {
		getRequest();
	}

	@Then("the response status code should be {int}")
	public void the_response_status_code_should_be(Integer statusCode) {
		Assert.assertEquals(response.statusCode(), statusCode);
	}

	@Then("the title of the second post should be {string}")
	public void the_title_of_the_second_post_should_be(String title) {
		Assert.assertEquals(response.jsonPath().getString("title[1]"), title);
	}

	@When("I send a GET request with query parameter PostId={int}")
	public void i_send_a_get_request_with_query_parameter_post_id(Integer postID) {
		getRequest("postId", postID.toString());
	}

	@Then("the comment posted user {string} should be displayed")
	public void the_comment_posted_user_should_be_displayed(String emailID) {
		Assert.assertEquals(response.jsonPath().getString("email[3]"), emailID);
	}

	@When("I send a POST request with new user details {string}")
	public void i_send_a_post_request_with_new_user_details(String jsonBodyFilePath) {
		postRequest_JsonFileAsBody(jsonBodyFilePath);
	}

	@Then("the Title should be {string}")
	public void the_title_should_be(String title) {
		Assert.assertEquals(response.jsonPath().getString("title"), title);
	}

	@Then("the Body should be {string}")
	public void the_body_should_be(String body) {
		Assert.assertEquals(response.jsonPath().getString("body"), body);
	}

	@Then("the user id should be {string}")
	public void the_user_id_should_be(String userID) {
		Assert.assertEquals(response.jsonPath().getString("userId"), userID);
	}

	@Then("the id should be {string}")
	public void the_id_should_be(String id) {
		Assert.assertEquals(response.jsonPath().getString("id"), id);
	}

	@When("I send a PUT request with existing user updated details {string}")
	public void i_send_a_put_request_with_existing_user_updated_details(String jsonBodyFilePath) {
		putRequest_JsonFileAsBody(jsonBodyFilePath);
	}

	@When("I send a PATCH request with existing user updated details {string}")
	public void i_send_a_patch_request_with_existing_user_updated_details(String jsonBodyFilePath) {
		patchRequest_JsonFileAsBody(jsonBodyFilePath);
	}
	
	@When("I send a DELET request")
	public void i_send_a_delet_request() {
	    deleteRequest();
	}


}
