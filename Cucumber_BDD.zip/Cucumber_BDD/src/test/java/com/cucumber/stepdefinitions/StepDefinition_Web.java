package com.cucumber.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.gherkin.model.Scenario;
import com.cucumber.drivers.InitializeDriver;
import com.cucumber.runner.TestRunner;
import com.cucumber.utils.CommonUtils;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class StepDefinition_Web extends TestRunner {

	@Given("launch application signup page")
	public void launch_application_signup_page() {
		driver.navigate().to("https://www.tutorialspoint.com/market/signup.jsp?v=1.0");		
	}
	
	@Given("enter last name {string}")
	public void enter_last_name(String lastName) {
		WebElement lName = driver.findElement(By.id("lastName"));
		lName.sendKeys(lastName);
	}

	@Given("enter email {string}")
	public void enter_email(String email) {
		WebElement eleEmail = driver.findElement(By.id("email"));
		eleEmail.sendKeys(email);
	}

	@Given("enter mobile number {string}>")
	public void enter_mobile_number(String mobileNumber) {
		WebElement phone = driver.findElement(By.id("phone"));
		phone.sendKeys(mobileNumber);
	}

	@When("I click next button")
	public void i_click_next_button() {
		driver.findElement(By.id("nextBtn")).click();
	}

	@Then("Please enter First name error message should be displayed")
	public void please_enter_first_name_error_message_should_be_displayed() {
//		InitializeDriver.waitUntilElementVisible(driver, "//*[@id='signup-form']/div[1]/div[2]/div/p");
		WebElement errorMsg = driver.findElement(By.xpath("//*[@id='signup-form']/div[1]/div[2]/div/p"));		
		boolean assertionflag = errorMsg.getText().equals("Please enter First name.") ? true : false;
		Assert.assertEquals(assertionflag, true);
	}
	
	@Then("error message {string} should be displayed")
	public void error_message_should_be_displayed(String expectedErrorMsg) {
		WebElement errorMsg = driver.findElement(By.xpath("//p[@class='error-message firstName--error-message']"));		
		boolean assertionflag = errorMsg.getText().equals(expectedErrorMsg) ? true : false;
		Assert.assertEquals(assertionflag, true);
	}
	
	@Given("enter first name from data sheet")
	public void enter_first_name_from_data_sheet() throws Exception {
		WebElement lName = driver.findElement(By.id("firstName"));
		lName.sendKeys(CommonUtils.getCellValue(Hooks.scenarioName, "FirstName"));
	}

	@Given("enter email from data sheet")
	public void enter_email_from_data_sheet() throws Exception {
		WebElement eleEmail = driver.findElement(By.id("email"));
		eleEmail.sendKeys(CommonUtils.getCellValue(Hooks.scenarioName, "Email"));
	}

	@Given("enter mobile number from data sheet")
	public void enter_mobile_number_from_data_sheet() throws Exception {
		WebElement phone = driver.findElement(By.id("phone"));
		phone.sendKeys(CommonUtils.getCellValue(Hooks.scenarioName, "MobileNumber"));
	}


	@Then("error message should be displayed as per the data sheet")
	public void error_message_should_be_displayed_as_per_the_data_sheet() throws Exception {
		WebElement errorMsg = driver.findElement(By.xpath("//p[@class='error-message lastName--error-message']"));		
		boolean assertionflag = errorMsg.getText().equals(CommonUtils.getCellValue(Hooks.scenarioName, "ErrorMessage")) ? true : false;
		Assert.assertEquals(assertionflag, true);
	}



}
