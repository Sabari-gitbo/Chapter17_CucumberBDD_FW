package com.cucumber.stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import com.cucumber.runner.TestRunner;

public class Hooks extends TestRunner{
	public static String scenarioName = "";

	@Before
	public void beforeScenarioName(Scenario sceanrioName) {
		scenarioName = sceanrioName.getName();
	}

	@After
	public void afterScenarioName(Scenario sceanrioName) {
		scenarioName = "";
	}
}
