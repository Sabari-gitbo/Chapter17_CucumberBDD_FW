import random
from tkinter import *
from tkinter import messagebox


class Bill_App:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.configure(bg="#0A7CFF")
        self.root.title("Grocery Billing System - by Harini Software")

        title = Label(self.root, text="Grocery Billing System", bd=12, relief=RIDGE, font=("Arial Black", 20),
                      bg="#A569BD", fg="white").pack(fill=X)

        # =================================== Variables =======================================================================================
        self.Apple = IntVar(value=0)
        self.Orange = IntVar(value=0)
        self.Mango = IntVar(value=0)
        self.Grapes = IntVar(value=0)
        self.Banana = IntVar(value=0)
        self.Papaya = IntVar(value=0)
        self.Pomegranate = IntVar(value=0)
        self.Rice = IntVar(value=0)
        self.Wheat = IntVar(value=0)
        self.Ragi = IntVar(value=0)
        self.oil = IntVar(value=0)
        self.sugar = IntVar(value=0)
        self.dal = IntVar(value=0)
        self.tea = IntVar(value=0)
        self.soap = IntVar(value=0)
        self.shampoo = IntVar(value=0)
        self.lotion = IntVar(value=0)
        self.cream = IntVar(value=0)
        self.foam = IntVar(value=0)
        self.mask = IntVar(value=0)
        self.sanitizer = IntVar(value=0)

        self.total_sna = StringVar()
        self.total_gro = StringVar()
        self.total_hyg = StringVar()

        self.a = StringVar()
        self.b = StringVar()
        self.c = StringVar()

        self.c_name = StringVar()
        self.bill_no = StringVar()
        self.phone = StringVar()

        x = random.randint(1000, 9999)
        self.bill_no.set(str(x))

        # ========================================== Customer Details Label Frame =================================================
        details = LabelFrame(self.root, text="Customer Details", font=("Arial Black", 12), bg="#A569BD", fg="white",
                             relief=GROOVE, bd=10)
        details.place(x=0, y=80, relwidth=1)

        cust_name = Label(details, text="Customer Name", font=("Arial Black", 14), bg="#A569BD", fg="white")
        cust_name.grid(row=0, column=0, padx=15)
        cust_entry = Entry(details, borderwidth=4, width=30, textvariable=self.c_name)
        cust_entry.grid(row=0, column=1, padx=8)

        contact_name = Label(details, text="Contact No.", font=("Arial Black", 14), bg="#A569BD", fg="white")
        contact_name.grid(row=0, column=2, padx=10)
        contact_entry = Entry(details, borderwidth=4, width=30, textvariable=self.phone)
        contact_entry.grid(row=0, column=3, padx=8)

        bill_name = Label(details, text="Bill.No.", font=("Arial Black", 14), bg="#A569BD", fg="white")
        bill_name.grid(row=0, column=4, padx=10)
        bill_entry = Entry(details, borderwidth=4, width=30, textvariable=self.bill_no)
        bill_entry.grid(row=0, column=5, padx=8)

        # ======================================= Fruits Menu ============================================================================
        fruits = LabelFrame(self.root, text="Fruits", font=("Arial Black", 12), bg="#E5B4F3", fg="#6C3483",
                            relief=GROOVE, bd=10)
        fruits.place(x=5, y=180, height=380, width=325)

        item1 = Label(fruits, text="Apple", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item1.grid(row=0, column=0, pady=11)
        item1_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Apple)
        item1_entry.grid(row=0, column=1, padx=10)

        item2 = Label(fruits, text="Orange", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item2.grid(row=1, column=0, pady=11)
        item2_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Orange)
        item2_entry.grid(row=1, column=1, padx=10)

        item3 = Label(fruits, text="Mango", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item3.grid(row=2, column=0, pady=11)
        item3_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Mango)
        item3_entry.grid(row=2, column=1, padx=10)

        item4 = Label(fruits, text="Grapes", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item4.grid(row=3, column=0, pady=11)
        item4_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Grapes)
        item4_entry.grid(row=3, column=1, padx=10)

        item5 = Label(fruits, text="Banana", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item5.grid(row=4, column=0, pady=11)
        item5_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Banana)
        item5_entry.grid(row=4, column=1, padx=10)

        item6 = Label(fruits, text="Papaya", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item6.grid(row=5, column=0, pady=11)
        item6_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Papaya)
        item6_entry.grid(row=5, column=1, padx=10)

        item7 = Label(fruits, text="Pomegranate", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item7.grid(row=6, column=0, pady=11)
        item7_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Pomegranate)
        item7_entry.grid(row=6, column=1, padx=10)

        # =================================== Grocery ==============================================================================
        grocery = LabelFrame(self.root, text="Grocery", font=("Arial Black", 12), relief=GROOVE, bd=10, bg="#E5B4F3",
                             fg="#6C3483")
        grocery.place(x=340, y=180, height=380, width=325)

        item8 = Label(grocery, text="Ponni Rice", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item8.grid(row=0, column=0, pady=11)
        item8_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.Rice)
        item8_entry.grid(row=0, column=1, padx=10)

        item9 = Label(grocery, text="Wheat", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item9.grid(row=1, column=0, pady=11)
        item9_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.Wheat)
        item9_entry.grid(row=1, column=1, padx=10)

        item10 = Label(grocery, text="Ragi", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item10.grid(row=2, column=0, pady=11)
        item10_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.Ragi)
        item10_entry.grid(row=2, column=1, padx=10)

        item11 = Label(grocery, text="Coconut oil", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item11.grid(row=3, column=0, pady=11)
        item11_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.oil)
        item11_entry.grid(row=3, column=1, padx=10)

        item12 = Label(grocery, text="White Sugar", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item12.grid(row=4, column=0, pady=11)
        item12_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.sugar)
        item12_entry.grid(row=4, column=1, padx=10)

        item13 = Label(grocery, text="Toor dal", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item13.grid(row=5, column=0, pady=11)
        item13_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.dal)
        item13_entry.grid(row=5, column=1, padx=10)

        item14 = Label(grocery, text="Tata Tea", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item14.grid(row=6, column=0, pady=11)
        item14_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.tea)
        item14_entry.grid(row=6, column=1, padx=10)

        # ============================ Hygiene Items ==========================================================================
        hygine = LabelFrame(self.root, text="Beauty & Hygiene", font=("Arial Black", 12), relief=GROOVE, bd=10,
                            bg="#E5B4F3", fg="#6C3483")
        hygine.place(x=670, y=180, height=380, width=325)

        item15 = Label(hygine, text="Dettol Soap", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item15.grid(row=0, column=0, pady=11)
        item15_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.soap)
        item15_entry.grid(row=0, column=1, padx=10)

        item16 = Label(hygine, text="Shampoo", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item16.grid(row=1, column=0, pady=11)
        item16_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.shampoo)
        item16_entry.grid(row=1, column=1, padx=10)

        item17 = Label(hygine, text="Body Lotion", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item17.grid(row=2, column=0, pady=11)
        item17_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.lotion)
        item17_entry.grid(row=2, column=1, padx=10)

        item18 = Label(hygine, text="Face Cream", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item18.grid(row=3, column=0, pady=11)
        item18_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.cream)
        item18_entry.grid(row=3, column=1, padx=10)

        item19 = Label(hygine, text="Foam Cleanser", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item19.grid(row=4, column=0, pady=11)
        item19_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.foam)
        item19_entry.grid(row=4, column=1, padx=10)

        item20 = Label(hygine, text="Face Mask", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item20.grid(row=5, column=0, pady=11)
        item20_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.mask)
        item20_entry.grid(row=5, column=1, padx=10)

        item21 = Label(hygine, text="Sanitizer", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item21.grid(row=6, column=0, pady=11)
        item21_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.sanitizer)
        item21_entry.grid(row=6, column=1, padx=10)

        # ============================================ Bill Area ==================================================================
        billframe = Label(self.root, bd=10, relief=GROOVE)
        billframe.place(x=1010, y=188, width=350, height=372)
        bill_title = Label(billframe, text="Bill", font=("Arial Black", 12), bd=7, relief=GROOVE)
        bill_title.pack(fill=X)
        scroll_y = Scrollbar(billframe, orient=VERTICAL)
        self.txtarea = Text(billframe, yscrollcommand=scroll_y.set)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_y.config(command=self.txtarea.yview)
        self.txtarea.pack(fill=BOTH, expand=1)

        # =================================================billing menu=========================================================================================
        billing_menu = LabelFrame(self.root, text="Billing Summary", font=("Arial Black", 12), relief=GROOVE, bd=10,
                                  bg="#A569BD", fg="white")
        billing_menu.place(x=0, y=560, relwidth=1, height=137)

        total_fruits = Label(billing_menu, text="Total Fruits Price", font=("Arial Black", 11), bg="#A569BD",
                             fg="white")
        total_fruits.grid(row=0, column=0)
        total_fruits_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.total_sna)
        total_fruits_entry.grid(row=0, column=1, padx=10, pady=7)

        total_grocery = Label(billing_menu, text="Total Grocery Price", font=("Arial Black", 11), bg="#A569BD",
                              fg="white")
        total_grocery.grid(row=1, column=0)
        total_grocery_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.total_gro)
        total_grocery_entry.grid(row=1, column=1, padx=10, pady=7)

        total_hygine = Label(billing_menu, text="Total Beauty & Hygeine Price", font=("Arial Black", 11), bg="#A569BD",
                             fg="white")
        total_hygine.grid(row=2, column=0)
        total_hygine_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.total_hyg)
        total_hygine_entry.grid(row=2, column=1, padx=10, pady=7)

        tax_fruits = Label(billing_menu, text="Fruits Tax", font=("Arial Black", 11), bg="#A569BD", fg="white")
        tax_fruits.grid(row=0, column=2)
        tax_fruits_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.a)
        tax_fruits_entry.grid(row=0, column=3, padx=10, pady=7)

        tax_grocery = Label(billing_menu, text="Grocery Tax", font=("Arial Black", 11), bg="#A569BD", fg="white")
        tax_grocery.grid(row=1, column=2)
        tax_grocery_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.b)
        tax_grocery_entry.grid(row=1, column=3, padx=10, pady=7)

        tax_hygine = Label(billing_menu, text="Beauty & Hygeine Tax", font=("Arial Black", 11), bg="#A569BD",
                           fg="white")
        tax_hygine.grid(row=2, column=2)
        tax_hygine_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.c)
        tax_hygine_entry.grid(row=2, column=3, padx=10, pady=7)

        button_frame = Frame(billing_menu, bd=7, relief=GROOVE, bg="#6C3483")
        button_frame.place(x=830, width=500, height=95)

        button_total = Button(button_frame, text="Total Bill", font=("Arial Black", 15), pady=10, bg="#E5B4F3",
                              fg="#6C3483", command=lambda: self.total())
        button_total.grid(row=0, column=0, padx=1)

        button_total = Button(button_frame, text="Generate Bill", font=("Arial Black", 15), pady=10, bg="#E5B4F3",
                              fg="#6C3483", command=lambda: self.bill_area())
        button_total.grid(row=0, column=1, padx=1)

        button_clear = Button(button_frame, text="Clear Field", font=("Arial Black", 15), pady=10, bg="#E5B4F3",
                              fg="#6C3483", command=lambda: self.clear())
        button_clear.grid(row=0, column=2, padx=10, pady=6)
        button_exit = Button(button_frame, text="Exit", font=("Arial Black", 15), pady=10, bg="#E5B4F3", fg="#6C3483",
                             width=8, command=lambda: self.exit())
        button_exit.grid(row=0, column=3, padx=10, pady=6)
        self.intro()

        def CombinedView():
            self.total()
            self.bill_area()

    # ======================= Total Function =============================================

    def total(self):
        self.total_fruits_price = (
                self.Apple.get() * 30 +
                self.Orange.get() * 20 +
                self.Mango.get() * 40 +
                self.Grapes.get() * 25 +
                self.Banana.get() * 10 +
                self.Papaya.get() * 25 +
                self.Pomegranate.get() * 50
        )
        self.total_grocery_price = (
                self.Rice.get() * 70 +
                self.Wheat.get() * 50 +
                self.Ragi.get() * 40 +
                self.oil.get() * 150 +
                self.sugar.get() * 35 +
                self.dal.get() * 60 +
                self.tea.get() * 120
        )
        self.total_hygiene_price = (
                self.soap.get() * 20 +
                self.shampoo.get() * 180 +
                self.lotion.get() * 200 +
                self.cream.get() * 100 +
                self.foam.get() * 150 +
                self.mask.get() * 50 +
                self.sanitizer.get() * 70
        )

        self.total_sna.set("Rs. " + str(self.total_fruits_price))
        self.total_gro.set("Rs. " + str(self.total_grocery_price))
        self.total_hyg.set("Rs. " + str(self.total_hygiene_price))

        self.total_all = self.total_fruits_price + self.total_grocery_price + self.total_hygiene_price
        self.a.set("Rs. " + str(self.total_all))

    def intro(self):
        self.txtarea.delete(1.0, END)
        self.txtarea.insert(END, "\tWELCOME TO SUPER MARKET\n\tPhone-No.9876543210")
        self.txtarea.insert(END, f"\n\nBill no. : {self.bill_no.get()}")
        self.txtarea.insert(END, f"\nCustomer Name : {self.c_name.get()}")
        self.txtarea.insert(END, f"\nPhone No. : {self.phone.get()}")
        self.txtarea.insert(END, "\n====================================\n")
        self.txtarea.insert(END, "\nProduct\t\tQty\tPrice\n")
        self.txtarea.insert(END, "\n====================================\n")

    # ======================= Bill Function =============================================

    def bill_area(self):
        self.total()
        self.txtarea.delete('1.0', END)
        self.txtarea.insert(END, "\tWelcome to Harini Software\n")
        self.txtarea.insert(END, f"\nBill Number : {self.bill_no.get()}")
        self.txtarea.insert(END, f"\nCustomer Name : {self.c_name.get()}")
        self.txtarea.insert(END, f"\nPhone Number : {self.phone.get()}")
        self.txtarea.insert(END, "\n====================================")
        self.txtarea.insert(END, "\nProduct\t\tQTY\tPrice")
        self.txtarea.insert(END, "\n====================================")
        self.add_item_to_bill("Apple", self.Apple.get(), 30)
        self.add_item_to_bill("Orange", self.Orange.get(), 20)
        self.add_item_to_bill("Mango", self.Mango.get(), 40)
        self.add_item_to_bill("Grapes", self.Grapes.get(), 25)
        self.add_item_to_bill("Banana", self.Banana.get(), 10)
        self.add_item_to_bill("Papaya", self.Papaya.get(), 25)
        self.add_item_to_bill("Pomegranate", self.Pomegranate.get(), 50)
        self.add_item_to_bill("Ponni Rice", self.Rice.get(), 70)
        self.add_item_to_bill("Wheat", self.Wheat.get(), 50)
        self.add_item_to_bill("Ragi", self.Ragi.get(), 40)
        self.add_item_to_bill("Coconut oil", self.oil.get(), 150)
        self.add_item_to_bill("White Sugar", self.sugar.get(), 35)
        self.add_item_to_bill("Toor dal", self.dal.get(), 60)
        self.add_item_to_bill("Tata Tea", self.tea.get(), 120)
        self.add_item_to_bill("Dettol Soap", self.soap.get(), 20)
        self.add_item_to_bill("Shampoo", self.shampoo.get(), 180)
        self.add_item_to_bill("Body Lotion", self.lotion.get(), 200)
        self.add_item_to_bill("Face Cream", self.cream.get(), 100)
        self.add_item_to_bill("Foam Cleanser", self.foam.get(), 150)
        self.add_item_to_bill("Face Mask", self.mask.get(), 50)
        self.add_item_to_bill("Sanitizer", self.sanitizer.get(), 70)
        self.txtarea.insert(END, "\n-------------------------------------")
        self.txtarea.insert(END, f"\nTotal Bill :\t\t{self.a.get()}")
        self.txtarea.insert(END, "\n-------------------------------------")
        self.txtarea.insert(END, "\nThanks for shopping with us!")
        self.save_bill()

    def add_item_to_bill(self, item_name, quantity, price_per_unit):
        if quantity > 0:
            total_price = quantity * price_per_unit
            self.txtarea.insert(END, f"\n{item_name}\t\t{quantity}\t{total_price}")

    # ======================= Clear Function =============================================

    def clear(self):
        self.txtarea.delete('1.0', END)
        self.c_name.set("")
        self.phone.set("")
        x = random.randint(1000, 9999)
        self.bill_no.set(str(x))

        self.Apple.set(0)
        self.Orange.set(0)
        self.Mango.set(0)
        self.Grapes.set(0)
        self.Banana.set(0)
        self.Papaya.set(0)
        self.Pomegranate.set(0)
        self.Rice.set(0)
        self.Wheat.set(0)
        self.Ragi.set(0)
        self.oil.set(0)
        self.sugar.set(0)
        self.dal.set(0)
        self.tea.set(0)
        self.soap.set(0)
        self.shampoo.set(0)
        self.lotion.set(0)
        self.cream.set(0)
        self.foam.set(0)
        self.mask.set(0)
        self.sanitizer.set(0)

        self.total_sna.set("")
        self.total_gro.set("")
        self.total_hyg.set("")
        self.a.set("")
        self.b.set("")
        self.c.set("")

    # ======================= Exit Function =============================================

    def exit(self):
        option = messagebox.askyesno("Exit", "Do you really want to exit?")
        if option:
            self.root.destroy()

    def save_bill(self):
        bill_details = self.txtarea.get('1.0', END)
        file_name = f"bills/{self.bill_no.get()}.txt"
        with open(file_name, 'w') as file:
            file.write(bill_details)
        messagebox.showinfo("Saved", f"Bill No. : {self.bill_no.get()} saved successfully")


root = Tk()
obj = Bill_App(root)
root.mainloop()
