import json
import tkinter as tk
from tkinter import messagebox


class AdminPage:
    def __init__(self, root):
        self.root = root
        self.root.geometry("600x400")
        self.root.title("Price Page")

        self.prices = self.load_prices()

        # Labels and Entries for price input
        self.create_price_input("Apple", 0, 0)
        self.create_price_input("Orange", 1, 0)
        self.create_price_input("Mango", 2, 0)
        self.create_price_input("Grapes", 3, 0)
        self.create_price_input("Banana", 4, 0)
        self.create_price_input("Papaya", 5, 0)
        self.create_price_input("Pomegranate", 6, 0)
        self.create_price_input("Rice", 0, 2)
        self.create_price_input("Wheat", 1, 2)
        self.create_price_input("Ragi", 2, 2)
        self.create_price_input("Oil", 3, 2)
        self.create_price_input("Sugar", 4, 2)
        self.create_price_input("Dal", 5, 2)
        self.create_price_input("Tea", 6, 2)
        self.create_price_input("Soap", 0, 4)
        self.create_price_input("Shampoo", 1, 4)
        self.create_price_input("Lotion", 2, 4)
        self.create_price_input("Cream", 3, 4)
        self.create_price_input("Foam", 4, 4)
        self.create_price_input("Mask", 5, 4)
        self.create_price_input("Sanitizer", 6, 4)

        # Save button
        save_button = tk.Button(self.root, text="Save Prices", command=self.save_prices)
        save_button.grid(row=7, column=2, columnspan=2, pady=20)

        # Clear All Prices button
        clear_button = tk.Button(self.root, text="Clear All Prices", command=self.clear_all_prices)
        clear_button.grid(row=7, column=4, columnspan=2, pady=20)

    def create_price_input(self, item, row, col):
        label = tk.Label(self.root, text=item)
        label.grid(row=row, column=col, padx=10, pady=5, sticky="w")
        entry = tk.Entry(self.root)
        entry.grid(row=row, column=col + 1, padx=10, pady=5)
        if item in self.prices:
            entry.insert(0, self.prices[item])

        setattr(self, f"{item}_entry", entry)

    def load_prices(self):
        try:
            with open('prices.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Error reading the prices file. It may be corrupted.")
            return {}

    def save_prices(self):
        prices = {}
        for item in [
            "Apple", "Orange", "Mango", "Grapes", "Banana", "Papaya", "Pomegranate",
            "Rice", "Wheat", "Ragi", "Oil", "Sugar", "Dal", "Tea",
            "Soap", "Shampoo", "Lotion", "Cream", "Foam", "Mask", "Sanitizer"
        ]:
            entry = getattr(self, f"{item}_entry")
            try:
                prices[item] = float(entry.get())
            except ValueError:
                messagebox.showerror("Error", f"Invalid input for {item}. Please enter a valid number.")
                return  # Exit the method if there's an invalid input

        with open('prices.json', 'w') as f:
            json.dump(prices, f, indent=4)

        messagebox.showinfo("Info", "Prices saved successfully!")

    def clear_all_prices(self):
        for item in [
            "Apple", "Orange", "Mango", "Grapes", "Banana", "Papaya", "Pomegranate",
            "Rice", "Wheat", "Ragi", "Oil", "Sugar", "Dal", "Tea",
            "Soap", "Shampoo", "Lotion", "Cream", "Foam", "Mask", "Sanitizer"
        ]:
            entry = getattr(self, f"{item}_entry")
            entry.delete(0, tk.END)  # Clear the entry field
        messagebox.showinfo("Info", "All prices cleared!")


if __name__ == "__main__":
    root = tk.Tk()
    app = AdminPage(root)
    root.mainloop()
