import json
import random
from tkinter import *
from tkinter import messagebox
import sqlite3
import subprocess  # For running external scripts
import sys


class Bill_App:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.configure(bg="#0A7CFF")
        self.root.title("Grocery Billing System - by Harini Software")

        title = Label(self.root, text="Grocery Billing System", bd=12, relief=RIDGE, font=("Arial Black", 20),
                      bg="#A569BD", fg="white").pack(fill=X)

        # =================================== Variables =======================================================================================
        self.Apple = IntVar(value=0)
        self.Orange = IntVar(value=0)
        self.Mango = IntVar(value=0)
        self.Grapes = IntVar(value=0)
        self.Banana = IntVar(value=0)
        self.Papaya = IntVar(value=0)
        self.Pomegranate = IntVar(value=0)
        self.Rice = IntVar(value=0)
        self.Wheat = IntVar(value=0)
        self.Ragi = IntVar(value=0)
        self.oil = IntVar(value=0)
        self.sugar = IntVar(value=0)
        self.dal = IntVar(value=0)
        self.tea = IntVar(value=0)
        self.soap = IntVar(value=0)
        self.shampoo = IntVar(value=0)
        self.lotion = IntVar(value=0)
        self.cream = IntVar(value=0)
        self.foam = IntVar(value=0)
        self.mask = IntVar(value=0)
        self.sanitizer = IntVar(value=0)

        self.total_sna = StringVar()
        self.total_gro = StringVar()
        self.total_hyg = StringVar()

        self.a = StringVar()
        self.b = StringVar()
        self.c = StringVar()

        self.c_name = StringVar()
        self.bill_no = StringVar()
        self.phone = StringVar()

        x = random.randint(1000, 9999)
        self.bill_no.set(str(x))

        def check_phone_exists(phone_number):
            conn = sqlite3.connect('customer_database.db')
            c = conn.cursor()
            c.execute("SELECT first_name, last_name FROM customers WHERE phone = ?", (phone_number,))
            customer = c.fetchone()
            conn.close()

            if customer is not None:
                cus1 = customer[0]
                cus2 = customer[1]
                cus = cus1 + " " + cus2
                return cus
            else:
                return None

        def on_phone_entry_focus_out(event):
            phone_number = self.phone.get()
            customer = check_phone_exists(phone_number)

            if customer:
                self.c_name.set(customer)  # Set the customer's name
            else:
                response = messagebox.askyesno("Customer Not Found", "Customer doesn't exist. Do you want to add?")
                if response:  # If user clicked 'Yes'
                    subprocess.Popen([sys.executable, 'admin_new.py'])
                # If 'No', simply continue with the billing process

        # ========================================== Customer Details Label Frame =================================================
        details = LabelFrame(self.root, text="Customer Details", font=("Arial Black", 12), bg="#A569BD", fg="white",
                             relief=GROOVE, bd=10)
        details.place(x=0, y=80, relwidth=1)

        contact_name = Label(details, text="Contact No.", font=("Arial Black", 14), bg="#A569BD", fg="white")
        contact_name.grid(row=0, column=0, padx=10)
        contact_entry = Entry(details, borderwidth=4, width=30, textvariable=self.phone)
        contact_entry.grid(row=0, column=1, padx=8)
        contact_entry.bind("<FocusOut>", on_phone_entry_focus_out)  # Bind the focus out event to check the phone number

        cust_name = Label(details, text="Customer Name", font=("Arial Black", 14), bg="#A569BD", fg="white")
        cust_name.grid(row=0, column=2, padx=15)
        cust_entry = Entry(details, borderwidth=4, width=30, textvariable=self.c_name, state="readonly")
        cust_entry.grid(row=0, column=3, padx=8)

        bill_name = Label(details, text="Bill.No.", font=("Arial Black", 14), bg="#A569BD", fg="white")
        bill_name.grid(row=0, column=4, padx=10)
        bill_entry = Entry(details, borderwidth=4, width=30, textvariable=self.bill_no)
        bill_entry.grid(row=0, column=5, padx=8)

        # ======================================= Fruits Menu ============================================================================
        fruits = LabelFrame(self.root, text="Fruits", font=("Arial Black", 12), bg="#E5B4F3", fg="#6C3483",
                            relief=GROOVE, bd=10)
        fruits.place(x=5, y=180, height=380, width=325)

        item1 = Label(fruits, text="Apple", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item1.grid(row=0, column=0, pady=11)
        item1_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Apple)
        item1_entry.grid(row=0, column=1, padx=10)

        item2 = Label(fruits, text="Orange", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item2.grid(row=1, column=0, pady=11)
        item2_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Orange)
        item2_entry.grid(row=1, column=1, padx=10)

        item3 = Label(fruits, text="Mango", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item3.grid(row=2, column=0, pady=11)
        item3_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Mango)
        item3_entry.grid(row=2, column=1, padx=10)

        item4 = Label(fruits, text="Grapes", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item4.grid(row=3, column=0, pady=11)
        item4_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Grapes)
        item4_entry.grid(row=3, column=1, padx=10)

        item5 = Label(fruits, text="Banana", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item5.grid(row=4, column=0, pady=11)
        item5_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Banana)
        item5_entry.grid(row=4, column=1, padx=10)

        item6 = Label(fruits, text="Papaya", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item6.grid(row=5, column=0, pady=11)
        item6_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Papaya)
        item6_entry.grid(row=5, column=1, padx=10)

        item7 = Label(fruits, text="Pomegranate", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item7.grid(row=6, column=0, pady=11)
        item7_entry = Entry(fruits, borderwidth=2, width=15, textvariable=self.Pomegranate)
        item7_entry.grid(row=6, column=1, padx=10)

        # =================================== Grocery ==============================================================================
        grocery = LabelFrame(self.root, text="Grocery", font=("Arial Black", 12), relief=GROOVE, bd=10, bg="#E5B4F3",
                             fg="#6C3483")
        grocery.place(x=340, y=180, height=380, width=325)

        item8 = Label(grocery, text="Ponni Rice", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item8.grid(row=0, column=0, pady=11)
        item8_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.Rice)
        item8_entry.grid(row=0, column=1, padx=10)

        item9 = Label(grocery, text="Wheat", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item9.grid(row=1, column=0, pady=11)
        item9_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.Wheat)
        item9_entry.grid(row=1, column=1, padx=10)

        item10 = Label(grocery, text="Ragi", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item10.grid(row=2, column=0, pady=11)
        item10_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.Ragi)
        item10_entry.grid(row=2, column=1, padx=10)

        item11 = Label(grocery, text="Coconut oil", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item11.grid(row=3, column=0, pady=11)
        item11_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.oil)
        item11_entry.grid(row=3, column=1, padx=10)

        item12 = Label(grocery, text="White Sugar", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item12.grid(row=4, column=0, pady=11)
        item12_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.sugar)
        item12_entry.grid(row=4, column=1, padx=10)

        item13 = Label(grocery, text="Toor dal", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item13.grid(row=5, column=0, pady=11)
        item13_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.dal)
        item13_entry.grid(row=5, column=1, padx=10)

        item14 = Label(grocery, text="Tata Tea", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item14.grid(row=6, column=0, pady=11)
        item14_entry = Entry(grocery, borderwidth=2, width=15, textvariable=self.tea)
        item14_entry.grid(row=6, column=1, padx=10)

        # ============================ Hygiene Items ==========================================================================
        hygine = LabelFrame(self.root, text="Beauty & Hygiene", font=("Arial Black", 12), relief=GROOVE, bd=10,
                            bg="#E5B4F3", fg="#6C3483")
        hygine.place(x=670, y=180, height=380, width=325)

        item15 = Label(hygine, text="Dettol Soap", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item15.grid(row=0, column=0, pady=11)
        item15_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.soap)
        item15_entry.grid(row=0, column=1, padx=10)

        item16 = Label(hygine, text="Shampoo", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item16.grid(row=1, column=0, pady=11)
        item16_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.shampoo)
        item16_entry.grid(row=1, column=1, padx=10)

        item17 = Label(hygine, text="Body Lotion", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item17.grid(row=2, column=0, pady=11)
        item17_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.lotion)
        item17_entry.grid(row=2, column=1, padx=10)

        item18 = Label(hygine, text="Face Cream", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item18.grid(row=3, column=0, pady=11)
        item18_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.cream)
        item18_entry.grid(row=3, column=1, padx=10)

        item19 = Label(hygine, text="Foam Cleanser", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item19.grid(row=4, column=0, pady=11)
        item19_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.foam)
        item19_entry.grid(row=4, column=1, padx=10)

        item20 = Label(hygine, text="Face Mask", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item20.grid(row=5, column=0, pady=11)
        item20_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.mask)
        item20_entry.grid(row=5, column=1, padx=10)

        item21 = Label(hygine, text="Sanitizer", font=("Arial Black", 11), bg="#E5B4F3", fg="#6C3483")
        item21.grid(row=6, column=0, pady=11)
        item21_entry = Entry(hygine, borderwidth=2, width=15, textvariable=self.sanitizer)
        item21_entry.grid(row=6, column=1, padx=10)

        # ============================================ Bill Area ==================================================================
        billframe = Label(self.root, bd=10, relief=GROOVE)
        billframe.place(x=1010, y=188, width=350, height=372)
        bill_title = Label(billframe, text="Bill", font=("Arial Black", 12), bd=7, relief=GROOVE)
        bill_title.pack(fill=X)
        scroll_y = Scrollbar(billframe, orient=VERTICAL)
        self.txtarea = Text(billframe, yscrollcommand=scroll_y.set)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_y.config(command=self.txtarea.yview)
        self.txtarea.pack(fill=BOTH, expand=1)

        # =================================================billing menu=========================================================================================
        billing_menu = LabelFrame(self.root, text="Billing Summary", font=("Arial Black", 12), relief=GROOVE, bd=10,
                                  bg="#A569BD", fg="white")
        billing_menu.place(x=0, y=560, relwidth=1, height=137)

        total_fruits = Label(billing_menu, text="Total Fruits Price", font=("Arial Black", 11), bg="#A569BD",
                             fg="white")
        total_fruits.grid(row=0, column=0)
        total_fruits_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.total_sna)
        total_fruits_entry.grid(row=0, column=1, padx=10, pady=7)

        total_grocery = Label(billing_menu, text="Total Grocery Price", font=("Arial Black", 11), bg="#A569BD",
                              fg="white")
        total_grocery.grid(row=1, column=0)
        total_grocery_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.total_gro)
        total_grocery_entry.grid(row=1, column=1, padx=10, pady=7)

        total_hygine = Label(billing_menu, text="Total Beauty & Hygeine Price", font=("Arial Black", 11), bg="#A569BD",
                             fg="white")
        total_hygine.grid(row=2, column=0)
        total_hygine_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.total_hyg)
        total_hygine_entry.grid(row=2, column=1, padx=10, pady=7)

        tax_fruits = Label(billing_menu, text="Fruits Tax", font=("Arial Black", 11), bg="#A569BD", fg="white")
        tax_fruits.grid(row=0, column=2)
        tax_fruits_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.a)
        tax_fruits_entry.grid(row=0, column=3, padx=10, pady=7)

        tax_grocery = Label(billing_menu, text="Grocery Tax", font=("Arial Black", 11), bg="#A569BD", fg="white")
        tax_grocery.grid(row=1, column=2)
        tax_grocery_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.b)
        tax_grocery_entry.grid(row=1, column=3, padx=10, pady=7)

        tax_hygine = Label(billing_menu, text="Beauty & Hygeine Tax", font=("Arial Black", 11), bg="#A569BD",
                           fg="white")
        tax_hygine.grid(row=2, column=2)
        tax_hygine_entry = Entry(billing_menu, width=30, borderwidth=2, textvariable=self.c)
        tax_hygine_entry.grid(row=2, column=3, padx=10, pady=7)

        button_frame = Frame(billing_menu, bd=7, relief=GROOVE, bg="#6C3483")
        button_frame.place(x=830, width=500, height=95)

        button_total = Button(button_frame, text="Total Bill", font=("Arial Black", 15), pady=10, bg="#E5B4F3",
                              fg="#6C3483", command=lambda: self.total())
        button_total.grid(row=0, column=0, padx=1)

        button_generate = Button(button_frame, text="Generate Bill", font=("Arial Black", 15), pady=10, bg="#E5B4F3",
                                 fg="#6C3483", command=lambda: self.bill_area())
        button_generate.grid(row=0, column=1, padx=1)

        button_clear = Button(button_frame, text="Clear Field", font=("Arial Black", 15), pady=10, bg="#E5B4F3",
                              fg="#6C3483", command=lambda: self.clear())
        button_clear.grid(row=0, column=2, padx=10, pady=6)
        button_exit = Button(button_frame, text="Exit", font=("Arial Black", 15), pady=10, bg="#E5B4F3", fg="#6C3483",
                             width=8, command=lambda: self.exit())
        button_exit.grid(row=0, column=3, padx=10, pady=6)
        self.intro()
        self.load_prices()

        def CombinedView():
            self.total()
            self.bill_area()

    # ======================= Read Price Function =============================================
    def load_prices(self):
        with open(r'C:\Users\SBRWBGVFST\Desktop\Grocery_Billing\billing_pages\prices.json', 'r') as file:
            self.prices = json.load(file)

    # ======================= Total Function =============================================
    def total(self):
        # Get values from the UI
        apple_qty = self.Apple.get()
        orange_qty = self.Orange.get()
        mango_qty = self.Mango.get()
        grapes_qty = self.Grapes.get()
        banana_qty = self.Banana.get()
        papaya_qty = self.Papaya.get()
        pomegranate_qty = self.Pomegranate.get()

        rice_qty = self.Rice.get()
        wheat_qty = self.Wheat.get()
        ragi_qty = self.Ragi.get()
        oil_qty = self.oil.get()
        sugar_qty = self.sugar.get()
        dal_qty = self.dal.get()
        tea_qty = self.tea.get()

        soap_qty = self.soap.get()
        shampoo_qty = self.shampoo.get()
        lotion_qty = self.lotion.get()
        cream_qty = self.cream.get()
        foam_qty = self.foam.get()
        mask_qty = self.mask.get()
        sanitizer_qty = self.sanitizer.get()

        # Calculate total prices
        self.total_fruits_price = (
                apple_qty * self.prices.get("Apple", 0) +
                orange_qty * self.prices.get("Orange", 0) +
                mango_qty * self.prices.get("Mango", 0) +
                grapes_qty * self.prices.get("Grapes", 0) +
                banana_qty * self.prices.get("Banana", 0) +
                papaya_qty * self.prices.get("Papaya", 0) +
                pomegranate_qty * self.prices.get("Pomegranate", 0)
        )

        self.total_grocery_price = (
                rice_qty * self.prices.get("Rice", 0) +
                wheat_qty * self.prices.get("Wheat", 0) +
                ragi_qty * self.prices.get("Ragi", 0) +
                oil_qty * self.prices.get("Oil", 0) +
                sugar_qty * self.prices.get("Sugar", 0) +
                dal_qty * self.prices.get("Dal", 0) +
                tea_qty * self.prices.get("Tea", 0)
        )

        self.total_hygiene_price = (
                soap_qty * self.prices.get("Soap", 0) +
                shampoo_qty * self.prices.get("Shampoo", 0) +
                lotion_qty * self.prices.get("Lotion", 0) +
                cream_qty * self.prices.get("Cream", 0) +
                foam_qty * self.prices.get("Foam", 0) +
                mask_qty * self.prices.get("Mask", 0) +
                sanitizer_qty * self.prices.get("Sanitizer", 0)
        )

        # Set the total values to the Entry fields
        self.total_sna.set(f"{self.total_fruits_price:.2f}")
        self.total_gro.set(f"{self.total_grocery_price:.2f}")
        self.total_hyg.set(f"{self.total_hygiene_price:.2f}")

        # Calculate and set tax values (example: 5% tax rate)
        tax_rate = 0.05  # 5% tax rate
        tax_fruits = self.total_fruits_price * tax_rate
        tax_grocery = self.total_grocery_price * tax_rate
        tax_hygiene = self.total_hygiene_price * tax_rate

        self.a.set(f"{tax_fruits:.2f}")
        self.b.set(f"{tax_grocery:.2f}")
        self.c.set(f"{tax_hygiene:.2f}")

        self.total_bill = round(float(
            self.total_fruits_price + self.total_grocery_price + self.total_hygiene_price + tax_fruits + tax_grocery + tax_hygiene),
            2)

    def intro(self):
        self.txtarea.delete(1.0, END)
        self.txtarea.insert(END, "\tWELCOME TO SUPER MARKET\n\tPhone-No.9876543210")
        self.txtarea.insert(END, f"\n\nBill no. : {self.bill_no.get()}")
        self.txtarea.insert(END, f"\nCustomer Name : {self.c_name.get()}")
        self.txtarea.insert(END, f"\nPhone No. : {self.phone.get()}")
        self.txtarea.insert(END, "\n====================================\n")
        self.txtarea.insert(END, "\nProduct\t\tQty\tPrice\n")
        self.txtarea.insert(END, "\n====================================\n")

    # ======================= Bill Function =============================================

    def bill_area(self):
        if self.c_name.get() == "":
            messagebox.showinfo("Customer Details", "Please Enter Customer Name !")
        elif self.phone.get() == "":
            messagebox.showinfo("Customer Details", "Please Enter Customer Contact Number !")
        else:
            self.total()
            self.txtarea.delete('1.0', END)
            self.txtarea.insert(END, "\tWelcome to Harini Software\n")
            self.txtarea.insert(END, f"\nBill Number : {self.bill_no.get()}")
            self.txtarea.insert(END, f"\nCustomer Name : {self.c_name.get()}")
            self.txtarea.insert(END, f"\nPhone Number : {self.phone.get()}")
            self.txtarea.insert(END, "\n====================================")
            self.txtarea.insert(END, "\nProduct\t\tQTY\tPrice")
            self.txtarea.insert(END, "\n====================================")
            self.add_item_to_bill("Apple", self.Apple.get(), self.prices.get("Apple", 0))
            self.add_item_to_bill("Orange", self.Orange.get(), self.prices.get("Orange", 0))
            self.add_item_to_bill("Mango", self.Mango.get(), self.prices.get("Mango", 0))
            self.add_item_to_bill("Grapes", self.Grapes.get(), self.prices.get("Grapes", 0))
            self.add_item_to_bill("Banana", self.Banana.get(), self.prices.get("Banana", 0))
            self.add_item_to_bill("Papaya", self.Papaya.get(), self.prices.get("Papaya", 0))
            self.add_item_to_bill("Pomegranate", self.Pomegranate.get(), self.prices.get("Pomegranate", 0))
            self.add_item_to_bill("Ponni Rice", self.Rice.get(), self.prices.get("Rice", 0))
            self.add_item_to_bill("Wheat", self.Wheat.get(), self.prices.get("Wheat", 0))
            self.add_item_to_bill("Ragi", self.Ragi.get(), self.prices.get("Ragi", 0))
            self.add_item_to_bill("Coconut oil", self.oil.get(), self.prices.get("Oil", 0))
            self.add_item_to_bill("White Sugar", self.sugar.get(), self.prices.get("Sugar", 0))
            self.add_item_to_bill("Toor dal", self.dal.get(), self.prices.get("Dal", 0))
            self.add_item_to_bill("Tata Tea", self.tea.get(), self.prices.get("Tea", 0))
            self.add_item_to_bill("Dettol Soap", self.soap.get(), self.prices.get("Soap", 0))
            self.add_item_to_bill("Shampoo", self.shampoo.get(), self.prices.get("Shampoo", 0))
            self.add_item_to_bill("Body Lotion", self.lotion.get(), self.prices.get("Lotion", 0))
            self.add_item_to_bill("Face Cream", self.cream.get(), self.prices.get("Cream", 0))
            self.add_item_to_bill("Foam Cleanser", self.foam.get(), self.prices.get("Foam", 0))
            self.add_item_to_bill("Face Mask", self.mask.get(), self.prices.get("Mask", 0))
            self.add_item_to_bill("Sanitizer", self.sanitizer.get(), self.prices.get("Sanitizer", 0))
            self.txtarea.insert(END, "\n-------------------------------------")
            self.txtarea.insert(END, f"\nTotal Bill :\t\t{self.total_bill}  Rs")
            self.txtarea.insert(END, "\n-------------------------------------")
            self.txtarea.insert(END, "\nThanks for shopping with us!")
            self.save_bill()

    def add_item_to_bill(self, item_name, quantity, price_per_unit):
        if quantity > 0:
            total_price = quantity * price_per_unit
            self.txtarea.insert(END, f"\n{item_name}\t\t{quantity}\t{total_price}")

    # ======================= Clear Function =============================================

    def clear(self):
        self.txtarea.delete('1.0', END)
        self.c_name.set("")
        self.phone.set("")
        x = random.randint(1000, 9999)
        self.bill_no.set(str(x))

        self.Apple.set(0)
        self.Orange.set(0)
        self.Mango.set(0)
        self.Grapes.set(0)
        self.Banana.set(0)
        self.Papaya.set(0)
        self.Pomegranate.set(0)
        self.Rice.set(0)
        self.Wheat.set(0)
        self.Ragi.set(0)
        self.oil.set(0)
        self.sugar.set(0)
        self.dal.set(0)
        self.tea.set(0)
        self.soap.set(0)
        self.shampoo.set(0)
        self.lotion.set(0)
        self.cream.set(0)
        self.foam.set(0)
        self.mask.set(0)
        self.sanitizer.set(0)

        self.total_sna.set("")
        self.total_gro.set("")
        self.total_hyg.set("")
        self.a.set("")
        self.b.set("")
        self.c.set("")

    # ======================= Exit Function =============================================

    def exit(self):
        option = messagebox.askyesno("Exit", "Do you really want to exit?")
        if option:
            self.root.destroy()

    def save_bill(self):
        import smtplib
        import sqlite3
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from email.mime.base import MIMEBase
        from email import encoders
        from tkinter import messagebox

        # Save the bill locally
        bill_details = self.txtarea.get('1.0', END)
        file_name = f"Grocery_Billing/bills/{self.bill_no.get()}.txt"
        with open(file_name, 'w') as file:
            file.write(bill_details)
        messagebox.showinfo("Saved", f"Bill No. : {self.bill_no.get()} saved successfully")

        # Retrieve the customer's email ID from the database
        conn = sqlite3.connect('customer_database.db')  # Replace with your actual database
        cursor = conn.cursor()
        cursor.execute("SELECT email FROM customers WHERE phone = ?", (self.phone.get(),))
        customer_email = cursor.fetchone()
        conn.close()

        if customer_email:
            customer_email = customer_email[0]

            # Send the bill via email using a mock SMTP server
            from_email = "sabaripcet@gmail.com"
            subject = f"Bill No. {self.bill_no.get()}"

            msg = MIMEMultipart()
            msg['From'] = from_email
            msg['To'] = customer_email
            msg['Subject'] = subject

            body = f"Dear Customer,\n\nPlease find attached the bill for your recent purchase. Bill No: {self.bill_no.get()}.\n\nThank you for shopping with us!"
            msg.attach(MIMEText(body, 'plain'))

            attachment = open(file_name, "rb")
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f"attachment; filename= {file_name}")

            msg.attach(part)

            # Connect to the mock SMTP server
            server = smtplib.SMTP('localhost', 1025)  # Connect to the local mock SMTP server
            text = msg.as_string()
            server.sendmail(from_email, customer_email, text)
            server.quit()

            messagebox.showinfo("Email Sent",
                                f"Bill No. : {self.bill_no.get()} sent to {customer_email} successfully (using mock SMTP server)")
        else:
            messagebox.showwarning("Email Not Sent", "Customer email not found in the database.")


root = Tk()
obj = Bill_App(root)
root.mainloop()
