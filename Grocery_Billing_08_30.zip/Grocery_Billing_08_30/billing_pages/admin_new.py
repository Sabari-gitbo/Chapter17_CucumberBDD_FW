import sqlite3
import subprocess  # Import subprocess for running external scripts
import sys
import tkinter as tk
from tkinter import *
from tkinter import messagebox, ttk


def create_customer_database():
    # Connect to the SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect('customer_database.db')
    c = conn.cursor()

    # Create a table
    c.execute('''
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            address TEXT
        )
    ''')

    # Commit the changes and close the connection
    conn.commit()
    conn.close()


create_customer_database()


def add_customer(first_name, last_name, email, phone=None, address=None):
    conn = sqlite3.connect('customer_database.db')
    c = conn.cursor()

    try:
        c.execute('''
            INSERT INTO customers (first_name, last_name, email, phone, address)
            VALUES (?, ?, ?, ?, ?)
        ''', (first_name, last_name, email, phone, address))

        conn.commit()
    except sqlite3.IntegrityError:
        print("Error: Customer with this email already exists.")
    finally:
        conn.close()


def get_customers():
    conn = sqlite3.connect('customer_database.db')
    c = conn.cursor()

    c.execute('SELECT * FROM customers')
    customers = c.fetchall()

    conn.close()
    return customers


def update_customer(customer_id, first_name=None, last_name=None, email=None, phone=None, address=None):
    conn = sqlite3.connect('customer_database.db')
    c = conn.cursor()

    if first_name:
        c.execute('UPDATE customers SET first_name = ? WHERE id = ?', (first_name, customer_id))
    if last_name:
        c.execute('UPDATE customers SET last_name = ? WHERE id = ?', (last_name, customer_id))
    if email:
        c.execute('UPDATE customers SET email = ? WHERE id = ?', (email, customer_id))
    if phone:
        c.execute('UPDATE customers SET phone = ? WHERE id = ?', (phone, customer_id))
    if address:
        c.execute('UPDATE customers SET address = ? WHERE id = ?', (address, customer_id))

    conn.commit()
    conn.close()


def delete_customer(customer_id):
    conn = sqlite3.connect('customer_database.db')
    c = conn.cursor()

    c.execute('DELETE FROM customers WHERE id = ?', (customer_id,))

    conn.commit()
    conn.close()


# GUI functions
def refresh_customer_list():
    for row in tree.get_children():
        tree.delete(row)
    for customer in get_customers():
        tree.insert('', 'end', values=customer)


def add_customer_gui():
    first_name = entry_first_name.get()
    last_name = entry_last_name.get()
    email = entry_email.get()
    phone = entry_phone.get()
    address = entry_address.get()
    if not first_name or not last_name or not email:
        messagebox.showerror("Error", "First name, last name, and email are required.")
    else:
        add_customer(first_name, last_name, email, phone, address)
        refresh_customer_list()


def update_customer_gui():
    selected_item = tree.selection()
    if not selected_item:
        messagebox.showerror("Error", "Select a customer to update.")
        return
    customer_id = tree.item(selected_item[0], 'values')[0]
    first_name = entry_first_name.get()
    last_name = entry_last_name.get()
    email = entry_email.get()
    phone = entry_phone.get()
    address = entry_address.get()
    if not first_name or not last_name or not email:
        messagebox.showerror("Error", "First name, last name, and email are required.")
    else:
        update_customer(customer_id, first_name, last_name, email, phone, address)
        refresh_customer_list()


def delete_customer_gui():
    selected_item = tree.selection()
    if not selected_item:
        messagebox.showerror("Error", "Select a customer to delete.")
        return
    customer_id = tree.item(selected_item[0], 'values')[0]
    delete_customer(customer_id)
    refresh_customer_list()


def open_price_page():
    # Launch the admin.py script
    subprocess.Popen([sys.executable, 'price_page.py'])


# Set up Tkinter window
customer = Tk()
customer.title("Customer Database")

# Create and place widgets
frame = tk.Frame()
frame.pack(padx=10, pady=10)

tk.Label(frame, text="First Name").grid(row=0, column=0, padx=5, pady=5)
tk.Label(frame, text="Last Name").grid(row=1, column=0, padx=5, pady=5)
tk.Label(frame, text="Email").grid(row=2, column=0, padx=5, pady=5)
tk.Label(frame, text="Phone").grid(row=3, column=0, padx=5, pady=5)
tk.Label(frame, text="Address").grid(row=4, column=0, padx=5, pady=5)

entry_first_name = tk.Entry(frame)
entry_last_name = tk.Entry(frame)
entry_email = tk.Entry(frame)
entry_phone = tk.Entry(frame)
entry_address = tk.Entry(frame)

entry_first_name.grid(row=0, column=1, padx=5, pady=5)
entry_last_name.grid(row=1, column=1, padx=5, pady=5)
entry_email.grid(row=2, column=1, padx=5, pady=5)
entry_phone.grid(row=3, column=1, padx=5, pady=5)
entry_address.grid(row=4, column=1, padx=5, pady=5)

tk.Button(frame, text="Add Customer", command=add_customer_gui).grid(row=5, column=0, padx=5, pady=5, columnspan=2)
tk.Button(frame, text="Update Customer", command=update_customer_gui).grid(row=6, column=0, padx=5, pady=5,
                                                                           columnspan=2)
tk.Button(frame, text="Delete Customer", command=delete_customer_gui).grid(row=7, column=0, padx=5, pady=5,
                                                                           columnspan=2)

# Add new button to open admin page
tk.Button(frame, text="Add Product Price", command=open_price_page).grid(row=8, column=0, padx=5, pady=5, columnspan=2)

# Create a Treeview widget to display customers
tree = ttk.Treeview(columns=("ID", "First Name", "Last Name", "Email", "Phone", "Address"), show='headings')
tree.heading("ID", text="ID")
tree.heading("First Name", text="First Name")
tree.heading("Last Name", text="Last Name")
tree.heading("Email", text="Email")
tree.heading("Phone", text="Phone")
tree.heading("Address", text="Address")
tree.pack(padx=10, pady=10, fill='both', expand=True)

# Refresh the customer list on startup
refresh_customer_list()

customer.mainloop()
