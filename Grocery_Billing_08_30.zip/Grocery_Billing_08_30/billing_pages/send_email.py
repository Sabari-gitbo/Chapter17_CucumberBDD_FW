import smtplib
import sqlite3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from tkinter import messagebox
from tkinter.constants import END


def save_bill(self):
    # Save the bill locally
    bill_details = self.txtarea.get('1.0', END)
    file_name = f"Grocery_Billing/bills/{self.bill_no.get()}.txt"
    with open(file_name, 'w') as file:
        file.write(bill_details)
    messagebox.showinfo("Saved", f"Bill No. : {self.bill_no.get()} saved successfully")

    # Retrieve the customer's email ID from the database
    conn = sqlite3.connect('customer_database.db')  # Replace with your actual database
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM customers WHERE phone = ?", (self.phone_number.get(),))
    customer_email = cursor.fetchone()
    conn.close()

    if customer_email:
        customer_email = customer_email[0]

        # Send the bill via email
        from_email = "your_email@example.com"
        from_password = "your_password"
        subject = f"Bill No. {self.bill_no.get()}"

        msg = MIMEMultipart()
        msg['From'] = from_email
        msg['To'] = customer_email
        msg['Subject'] = subject

        body = f"Dear Customer,\n\nPlease find attached the bill for your recent purchase. Bill No: {self.bill_no.get()}.\n\nThank you for shopping with us!"
        msg.attach(MIMEText(body, 'plain'))

        attachment = open(file_name, "rb")
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f"attachment; filename= {file_name}")

        msg.attach(part)

        server = smtplib.SMTP('smtp.gmail.com', 587)  # Replace with your email provider's SMTP server
        server.starttls()
        server.login(from_email, from_password)
        text = msg.as_string()
        server.sendmail(from_email, customer_email, text)
        server.quit()

        messagebox.showinfo("Email Sent", f"Bill No. : {self.bill_no.get()} sent to {customer_email} successfully")
    else:
        messagebox.showwarning("Email Not Sent", "Customer email not found in the database.")
