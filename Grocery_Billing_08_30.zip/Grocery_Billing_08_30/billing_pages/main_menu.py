import subprocess
import sys
from tkinter import *


class MainMenu:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.configure(bg="#0A7CFF")
        self.root.title("Grocery Billing System - by Harini Software")

        Label(self.root, text="Grocery Billing System", bd=12, relief=RIDGE, font=("Arial Black", 60),
              bg="#A569BD", fg="white").pack(fill=X)

        # Create a Menu frame to hold the buttons
        menu_frame = LabelFrame(self.root, text="Menu", font=("Arial Black", 14), bg="#A569BD", fg="white", bd=10)

        # Center the menu frame on the page
        menu_frame.place(relx=0.5, rely=0.5, anchor=CENTER)

        # Billing System Button
        billing_button = Button(menu_frame, text="Billing System", font=("Arial Black", 14), bg="#E5B4F3", fg="#6C3483",
                                command=self.open_billing_system)
        billing_button.grid(row=0, column=0, padx=20, pady=10)

        # Admin View Button
        admin_button = Button(menu_frame, text="Admin View", font=("Arial Black", 14), bg="#E5B4F3", fg="#6C3483",
                              command=self.open_admin_view)
        admin_button.grid(row=0, column=1, padx=20, pady=10)

    def open_billing_system(self):
        subprocess.Popen([sys.executable, 'bill_app.py'])

    def open_admin_view(self):
        subprocess.Popen([sys.executable, 'admin_new.py'])


if __name__ == "__main__":
    root = Tk()
    app = MainMenu(root)
    root.mainloop()
